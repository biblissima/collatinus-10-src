#ifndef TRAITS_H
#define TRAITS_H

#include <QObject>
#include <QString>
#include <QStringList>
#include <QBitArray>
/*
const QStringList c = QString ("n,v,ac,g,d,ab").split (",");
const QStringList g = QString ("m,f,nt").split (",");
const QStringList n = QString ("s,p").split (",");
const QStringList d = QString ("comp,sup").split (",");
const QStringList p = QString ("1,2,3").split (",");
const QStringList t = QString ("pr,fut,impf,pf,fa,pqp").split (",");
const QStringList m = QString ("ind,subj,imper,inf,part,ger,adjv").split (",");
const QStringList v = QString ("act,pass").split (",");
*/
const QString cass [8] =
{"", "nom.", "uoc.", "acc.", "gen.", "dat.", "abl.", "loc."};
const QString genres [4] = {"", "masc.", "fem.", "neut."};
const QString nombres [3] = { "", "sing.", "plur."};
const QString personnes [4] = { "", "prim.", "sec.", "tert."};
const QString degres [4] = { "", "posit.", "compar.", "superl."};
const QString tempss [7] = { "", "praes.", "fut.", "imperf.", "perf.",
                      "fut. ant.", "plus-quam-perf."};
const QString modes [9] =
{
    "", "ind.", "coniunct.", "imper.", "infin.", // 0 - 4
    "part.", "gerund.", "adiect. verb.", "supin"          // 5 - 8
};

const QString voixs [3] = { "", "act.", "pass."};



class Traits : public QObject
{
    Q_OBJECT
private:
    QBitArray bits;
public:
//    explicit Traits(QObject *parent = 0);
    Traits (int k, int g, int n, int d, int p, int t, int m, int v);
    virtual ~Traits ();
    QBitArray getBits ();
    QString humain ();
    int casus ();
    int genus ();
    int numerus ();
    int gradus ();
    int persona ();
    int tempus ();
    int modus ();
    int uox ();
    bool contient (Traits * t);
    /*
    QString cas ();
    QString genre ();
    QString nombre ();
    QString degre ();
    QString personne ();
    QString temps ();
    QString mode ();
    QString voix ();
    */

signals:
    
public slots:
    
};

#endif // TRAITS_H
